<template> <div>用户列表</div></template>

<script>
export default {
  name: "userIndex",
  data() {
    return {};
  }
};
</script>

<style scoped></style>
