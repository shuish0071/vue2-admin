<template>
  <div>控制台首页</div>
</template>

<script>
export default {
  name: "index"
};
</script>

<style lang="scss" scoped></style>
